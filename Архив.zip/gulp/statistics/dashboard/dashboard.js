const filesCanvas = document.getElementById("filesChart");
const timeCanvas = document.getElementById("timeChart");

fetch("/__stats/data")
  .then((r) => r.json())
  .then((data) => {
    // График изменения файлов
    new Chart(filesCanvas, {
      type: "bar",
      data: {
        labels: Object.keys(data.files),
        datasets: [
          {
            label: "Изменения файлов",
            data: Object.values(data.files),
            backgroundColor: "rgba(54, 162, 235, 0.6)",
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: true } },
      },
    });
  })
  .catch((err) => console.error("Ошибка при загрузке статистики:", err));
